from  classes import CBattleground as C
import threading
#load battleground

bg = C.CBattleground()

while bg.keepGoing:  
    if bg.history == True:
        historyData = bg.getHistory()
        bg.init(historyData)
    else:
        bg.init()
    bg.prepare()
    bg.run()



