from . import CAvatar

class CEnemy(CAvatar.CAvatar):
    def __init__(self, pos=[0,0]):
        self.position = pos
        CAvatar.CAvatar.__init__(self)    

    def move(self):
        self.position[1] +=3
