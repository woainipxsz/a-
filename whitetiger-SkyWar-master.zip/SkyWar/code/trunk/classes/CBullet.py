import pygame
from pygame.locals import *
class CBullet():
    
    def __init__(self, pos):
        self.image=pygame.image.load("resources/images/bomb-1.bmp")
        self.position = pos
        return
    
    def move(self):
        self.position[1] -=10

    def moveDown(self):
        self.position[1] +=5
        
