from . import CAvatar
import socket

class CPlane(CAvatar.CAvatar):
    
    def __init__(self, pos =[240,600], healthValue = 194, isServer= True):
        if isServer == True: 
            self.image=self.pygame.image.load("resources/images/hero.bmp")
        else:
            self.image=self.pygame.image.load("resources/images/hero-1.bmp")

        self.position=pos
        #change imagesize
        self.img01_w =self.image.get_width()/2
        self.img01_h =self.image.get_height()/2
        self.image = self.pygame.transform.scale(self.image,(int(self.img01_w),int(self.img01_h)))
        
        self.healthValue = healthValue 
        self.healthbar = self.pygame.image.load("resources/images/healthbar.png")
        self.health = self.pygame.image.load("resources/images/health.png")
        self.connect = False

    def move(self, keys, height,width, connect):
        pace = 5
        if keys[0]:
            self.position[1]-=pace
        elif keys[2]:
            self.position[1]+=pace
        if keys[1]:
            self.position[0]-=pace
        elif keys[3]:
            self.position[0]+=pace

        if self.position[1] < 0:
            self.position[1] =0
        elif self.position[1] > height - self.img01_h:
            self.position[1] =height - self.img01_h
        if self.position[0] < 0:
            self.position[0] =0
        elif self.position[0] > width- self.img01_w:
            self.position[0] =width - self.img01_w

    def fight(self):
        return        
