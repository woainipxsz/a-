from . import CAvatar

class COnlineplane(CAvatar.CAvatar):

    def __init__(self, pos=[240, 600], healthValue=194, isServer = True):
        if isServer == True: 
            self.image=self.pygame.image.load("resources/images/hero.bmp")
        else:
            self.image=self.pygame.image.load("resources/images/hero-1.bmp")
        self.position = pos
        # change imagesize
        self.img01_w = self.image.get_width() / 2
        self.img01_h = self.image.get_height() / 2
        self.image = self.pygame.transform.scale(self.image, (int(self.img01_w), int(self.img01_h)))

        self.healthValue = healthValue
        self.healthbar = self.pygame.image.load("resources/images/healthbar.png")
        self.health = self.pygame.image.load("resources/images/health.png")

    def move(self, height,width, data =""):
        pace = 5
        if data  and isinstance(data, (str)) :
            data = data.split(";")
            data = data[0].split(",")
            self.position[0] = float(data[0])
            self.position[1] = float(data[1])
        
        if self.position[1] < 0:
            self.position[1] =0
        elif self.position[1] > height - self.img01_h:
            self.position[1] =height - self.img01_h
        if self.position[0] < 0:
            self.position[0] =0
        elif self.position[0] > width- self.img01_w:
            self.position[0] =width - self.img01_w

    def fight(self):
        return
