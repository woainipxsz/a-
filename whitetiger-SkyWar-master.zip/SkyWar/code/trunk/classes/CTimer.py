import threading
import time

class CTimer(threading.Thread):
    def __init__(self, seconds,q,pauseQ):
        self.pauseQ = pauseQ
        self.runTime = seconds
        self.q = q
        threading.Thread.__init__(self)
        self.delay =0
    def run(self):
        i=0
        while True:
            i+=1
            #print(self.pauseQ.empty()) 
            if not self.pauseQ.empty() and  self.runTime>0.5:
                self.delay +=1
                if(self.delay >2):
                    self.delay=2
                time.sleep(self.delay)
            else:
                self.q.put(i)
                self.delay =0
            time.sleep(self.runTime)

