from . import CAvatar
class CExplosion(CAvatar.CAvatar):
     def __init__(self, pos =[0,0]):
        self.position = pos
        self.image=self.pygame.image.load("resources/images/explosion-1.bmp")
        self.lifeValue = 4
