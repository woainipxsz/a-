import pygame
from pygame.locals import *

class Blood():
    def __init__(self,pos=[0,0]):
        self.position=pos
        self.image=pygame.image.load("resources/images/blood-1.bmp")
    
    def move(self):
        self.position[1]+=2
    
        
     
