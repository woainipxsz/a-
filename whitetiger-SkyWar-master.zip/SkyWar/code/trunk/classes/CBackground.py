import pygame
from pygame.locals import *

class CBackground:
    def __init__(self,height):
        self.image=pygame.image.load("resources/images/background5.bmp")
        self.position = [0, -height]  
    def move(self,height):
        #move background
        self.position[1] = self.position[1] +1
        if self.position[1]>height/16:
            self.position[1]=-height
