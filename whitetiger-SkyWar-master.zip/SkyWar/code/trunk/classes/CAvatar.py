import pygame
from pygame.locals import *
class CAvatar():
    pygame = pygame
    image=pygame.image.load("resources/images/enemyDown-1.bmp")
    position = [0,0]
        
    def move(self):
        return
        
