import pygame
from pygame.locals import *
class CSBullet():
    def __init__(self,pos):
        self.image=pygame.image.load("resources/images/bombs.jpg")
        self.position=pos
        return

    def move(self):
        self.position[1]-=10

    def movedown(self):
        self.position[1]+=5
