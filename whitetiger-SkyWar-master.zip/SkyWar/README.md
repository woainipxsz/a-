# SkyWar
面向对象期末大作业——空战游戏

git仓库分为code 和docs两大部分
    其中code 用于存放代码，code中又分为trunk、branch、和tag，这是按照标准的项目开发目录制定的，我们实际用到最多的是trunk目录。
    docs用于存放项目文档
